package Physics;

import java.awt.Graphics;

//TODO add explanation
public class Function2d {
	public Function2d() {

	}

	//What does this do?
	public void render(Graphics g) {

	}

	public double evaluate(Vector2d p) {
		return 0.0;
	}

	public Vector2d gradient(Vector2d p) {
		return null;
	}
}
