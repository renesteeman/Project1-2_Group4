import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NormalsGeneratorTest {
    @Test
    public void test(){
        assertEquals("true", "true");
    }
}