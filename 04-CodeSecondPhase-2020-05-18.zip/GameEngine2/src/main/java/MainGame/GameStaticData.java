package MainGame;

public class GameStaticData {
	static public final int SCALE = 10;
}