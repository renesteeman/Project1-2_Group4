package com.mygdx.game;

public enum UIState {
    GamePlay,
    HitWaterUI,
    ShootUI,
    WonScreen,
    Only3D;
}
