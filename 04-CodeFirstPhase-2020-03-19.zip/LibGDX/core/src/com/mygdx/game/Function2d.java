package com.mygdx.game;

//TODO what is this supposed to do?
public interface Function2d {
	public double evaluate(Vector2d p);
	public Vector2d gradient(Vector2d p);
}